import java.util.Scanner;

/** A class containing the four recursive methods required in Assignment 5 */
public class RecursionAssignment{

    private static int cvResult = 0;
    private static String rvResult = "";

    /**addDigits will recursively add digits of an integer entry until there are none left to add.*/
    public static int addDigits(int adEntry){
        if((adEntry % 10) != adEntry){    
            return ((adEntry % 10) + addDigits(adEntry / 10));
        } else{
            return adEntry % 10;
        }
    }

    /**sumEvenNumbers will recursively add all even numbers less than/equal to an integer.*/
    public static int sumEvenNumbers(int seEntry){
        if(seEntry > 0){
            if((seEntry  % 2) != 0){
                return (sumEvenNumbers(seEntry - 1));
            } else{
                return (seEntry + sumEvenNumbers(seEntry - 2));
            }
        } else{
            return seEntry;
        }        
    }

    /**countVowels will recursively count the number of vowels in a given string.*/
    public static int countVowels(String cvEntry){
        if(cvEntry.length() > 0){
            if(cvEntry.charAt(0) == 'a' || cvEntry.charAt(0) == 'e' || cvEntry.charAt(0) == 'i' ||
            cvEntry.charAt(0) == 'o' || cvEntry.charAt(0) == 'u'){
                cvResult += 1;
            }     
            return (countVowels(cvEntry.substring(1)));
        } else{
            return cvResult;
        }
    }

    /**removeVowels will recrursively remove all vowels in a given string.*/
    public static String removeVowels(String rvEntry){
        if(rvEntry.length() > 0){
            if(rvEntry.charAt(0) == 'a' || rvEntry.charAt(0) == 'e' || rvEntry.charAt(0) == 'i' ||
            rvEntry.charAt(0) == 'o' || rvEntry.charAt(0) == 'u'){
                return (removeVowels(rvEntry.substring(1)));
            } else{
                rvResult += rvEntry.charAt(0);
                return (removeVowels(rvEntry.substring(1)));
            }
        } else{
            return rvResult;
        }      

    }
 
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);   

        // Due to limitations/instability of the .nextXXXX() methods of Scanner class,
        // The methods that take a String argument will come before the ones that take int

        // countVowels
        System.out.println("Enter an word to return the number of vowels it contains:");
        System.out.println(countVowels(input.nextLine().toLowerCase()) + " vowels found.\n" + "");

        // removeVowels
        System.out.println("Enter an word to return the word without vowels:");
        System.out.println(removeVowels(input.nextLine().toLowerCase()) + "\n" + "");  

        // addDigits
        System.out.println("Enter an integer to return the sum of all digits:");
        System.out.println(addDigits(input.nextInt()) + "\n" + "");
        
        // sumEvenNumbers
        System.out.println("Enter an integer to return the sum of all less than/equal to it:");
        System.out.println(sumEvenNumbers(input.nextInt()) + "\n" + "");    

        input.close();
        System.exit(0);
    }
}
